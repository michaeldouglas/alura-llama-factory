# EscutIA LoRA

Adapter LoRA para classificação de sentimentos em português.

## Modelo-base

- modelo: `Qwen/Qwen2.5-0.5B-Instruct`
- revisão: `7ae557604adf67be50417f59c2c2f167def9a775`
- tarefa: classificação em `negativo`, `neutro` ou `positivo`

Este pacote contém um adapter LoRA, não um modelo completo. Para utilizar os
pesos, carregue o modelo-base compatível e aplique o adapter com PEFT.

```python
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel

base = AutoModelForCausalLM.from_pretrained("Qwen/Qwen2.5-0.5B-Instruct")
tokenizer = AutoTokenizer.from_pretrained("Qwen/Qwen2.5-0.5B-Instruct")
model = PeftModel.from_pretrained(base, "SEU_USUARIO/escutia-lora")
```

Os arquivos de avaliação incluídos neste pacote registram os resultados
observados no conjunto congelado do projeto.
