# EscutIA QLoRA

Adapter QLoRA para classificação de sentimentos em português.

## Modelo-base

- modelo: `Qwen/Qwen2.5-1.5B-Instruct`
- revisão: `989aa79`
- quantização do treinamento: 4 bits, NF4, double quantization
- tarefa: classificação em `negativo`, `neutro` ou `positivo`

Este repositório contém um adapter, não um modelo completo. Para usar os pesos, carregue o modelo-base e aplique o adapter com PEFT.

```python
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel

base = AutoModelForCausalLM.from_pretrained('Qwen/Qwen2.5-1.5B-Instruct')
tokenizer = AutoTokenizer.from_pretrained('Qwen/Qwen2.5-1.5B-Instruct')
model = PeftModel.from_pretrained(base, 'SEU_USUARIO/escutia-qlora')
```

Consulte os arquivos de avaliação e comparação incluídos neste pacote para conhecer o desempenho observado.
